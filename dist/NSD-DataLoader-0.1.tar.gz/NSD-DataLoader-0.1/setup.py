from setuptools import setup

setup(
    name='NSD-DataLoader',
    version='0.1',
    scripts=['NSD_DataLoader']
)
